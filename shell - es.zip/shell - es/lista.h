typedef struct
{
    pid_t pid;
    char command[256];
    char status[100];
    int isBackground;
} ITEM;

typedef struct NODE
{
    ITEM item;
    struct NODE *next;
} NODE;

typedef struct
{
    NODE *first;
    NODE *end;
} LIST;

void ListCreate(LIST *list)
{
    list->first = NULL;
    list->end = NULL;
}

int ListInsert(LIST *list, ITEM *item)
{
    NODE *newNode = (NODE *)malloc(sizeof(NODE)); //cria um novo nó

    if (newNode != NULL)   //verica se a memória foi alocada
    {
        newNode->item = *item; //preenche os dados
        newNode->next = NULL; //dene que o próximo é nulo

        if (list->first == NULL)   //se a list for vazia
        {
            list->first = newNode; //first aponta para novo
        }
        else
        {
            list->end->next = newNode; //next do m aponto para novo
        }

        list->end = newNode; //m aponta para novo
        return 1;
    }
    else
    {
        return 0;
    }
}

int ListGetByPid(LIST *list, pid_t pid, ITEM *item)
{
    NODE *aux = list->first;

    while (aux != NULL) {
        if (aux->item.pid == pid) {
            *item = aux->item;
            return 1;
        }
        aux = aux->next;
    }

    return 0;
}

int ListRemoveByPid(LIST *list, pid_t pid) {
    NODE *aux = list->first;
    NODE *prev = aux;
    while (aux != NULL) {
        if (aux->item.pid == pid) {
            prev->next = aux->next;
            free(&aux->item);
            free(aux);
            return 1;
        }
        prev = aux;
        aux = aux->next;
    }

    return 0;
}

LIST * childs;

