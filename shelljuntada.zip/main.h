#ifndef _MAIN_H_
#define _MAIN_H_
char * userdir;

int output_r;
int input_r;
char output_r_filename[100];
char input_r_filename[100];
char field0_name[100];
char field1_name[100];
int is_pipe;
int fd_out;
int fd_in;
pid_t fgChildPid;
int isBackground;
int child_handler_lock;
#endif
